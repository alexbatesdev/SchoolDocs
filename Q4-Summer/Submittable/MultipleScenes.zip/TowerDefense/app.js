
const sceneBoot = {
    key: 'boot',
    preload: function() {
        console.log('preload');
     },
    create: function () {
    this.add.text(20, 20, "Loading...", { font: "24px Arial", fill: "#ffffff" });
    console.log("HELLO I AM THE BOOT SCENE");
    this.scene.start('mainmenu');
}
};

const sceneMainMenu = {
    key: 'mainmenu',
    active: false,
    preload: function() {this.load.image('background', 'assets/mainMenuTest.png');
        console.log("HELLO I AM THE MAIN MENU SCENE");
    },
    create: function() {
        this.add.image(400, 300, 'background');
        this.add.text(20, 20, "Main Menu", { font: "24px Arial", fill: "#ffffff" });
    }



};
const sceneGame = {
    key: 'game',
    active: false,
    preload: function(){
        console.log("starting our game!")
    },
    create: function() {
        this.add.text(20, 20, "Game", { font: "24px Arial", fill: "#ffffff" });
    }

};


var config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    scene: [sceneBoot, sceneMainMenu]
};

var game = new Phaser.Game(config);

