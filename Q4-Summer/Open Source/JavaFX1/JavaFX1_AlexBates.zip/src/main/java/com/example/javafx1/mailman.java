package com.example.javafx1;

public class mailman {
    public static int score = 0;
    public static int missed = 0;
}
