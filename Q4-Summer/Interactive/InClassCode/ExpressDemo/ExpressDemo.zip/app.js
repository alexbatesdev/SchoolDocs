const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static("public"));

// Telling express where our views are
// and Telling express that we want to use pug
app.set("views", "./views");
app.set("view engine", "pug");

app.get( // .get means this will handle a get request
    "/", // This defines a route/endpoint for the root of the site
    (req, res) => { //reg = reguest, res = response
        res.render("home");
    }
)

app.get("/features", (req, res) => { 
    // Features page
        res.render("features")
    }
)

app.get("/order", (req, res) => { 
    // Order page
    res.render("order")
    }
)

app.get("/no", (req, res) => { 
    // Order page
    res.render("no")
    }
)

app.post("/order", (req, res) => { 
    console.log("POST:ORDER");
    let object = {
        "name": req.body.name,
        "email": req.body.email,
        "phone": req.body.phone,
        "address": req.body.address
    }
    let myJSON = JSON.stringify(object);

    try {
        fs.appendFile(`./public/orders/orders.json`, myJSON, err => console.log(err));
        //fs.writeFileSync();
    } catch (err) {
        console.error(err);
    }
    // Get order details from request
    // Save order details to file
    res.render("order");
}
)

app.listen(port, () => {
    console.log(`Listening on port ${port}`)
});