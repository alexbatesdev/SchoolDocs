const express = require("express");
const router = express.Router();

const dal = require("../data/mongoDAL");

router.get("/", (req, res) => {
    var resultJson = {
        data: [
            {
                name: "Arkadiusz",
                likes: 50
            }
        ]
    }
    res.send(resultJson);
});



module.exports = router;