const express = require("express");
const router = express.Router();

const bcrypt = require('bcrypt');

const dal = require("../data/mongoDAL");


router.get("/", (req, res) => {
    let html = `<h1>User Homepage</h1>`;
    let model = {
        loggedInUser: req.session.user
    }
    res.send(html, model);
});

router.post("/register", async (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    let confirmPassword = req.body.confirmPassword;
    let email = req.body.email;
    let age = req.body.age;
    let questions = [req.body.question1, req.body.question2, req.body.question3];

    let model = {
        loggedInUser: req.session.user
    }

    if (password == confirmPassword && password.length > 0) {
        let hashedPass = await bcrypt.hash(password, 10);

        let result = dal.createUser(username, hashedPass, email, age, questions);
        res.redirect("/u/login");
    } else {
        res.render("register", model);
    }
});

router.get("/register", (req, res) => {
    res.render("register");
});

router.get("/logout", (req, res) => {
    req.session.user = null; // destroy the session

    res.redirect('/');
});

router.get("/login", (req, res) => {
    let model = {
        loggedInUser: req.session.user
    }
    res.render("login", model);
});

router.post("/login", async (req, res) => {
    // Get values from posted from
    // (body parser)
    let username = req.body.username;
    let password = req.body.password;

    console.log('Login attempt - username: ' + username);

    let results = await dal.getUser(username);
    
    if (results) {
    
        let passwordsMatch = await bcrypt.compare(password, results.Password);

        if (passwordsMatch) {
            // Set the session
            // Don't put anything secure in the session because it ends up in the browser's cookies/local storage
            console.log(`Logging in ${username}`);

            var user = {};
            if (!results.Questions && !results.Age) {
                user = {
                    username: username,
                    userID: results._id, //Will come from database
                    age: null,
                    email: results.Email,
                    questions: [
                        ["What is your favorite color?", null],
                        ["What is your favorite animal?", null],
                        ["What is your favorite food?", null]
                    ],
                    isAdmin: false,
                    lastVisit: new Date()
                };
            } else if (!results.Questions) {
                user = {
                    username: username,
                    userID: results._id, //Will come from database
                    age: results.Age,
                    email: results.Email,
                    questions: [
                        ["What is your favorite color?", null],
                        ["What is your favorite animal?", null],
                        ["What is your favorite food?", null]
                    ],
                    isAdmin: false,
                    lastVisit: new Date()
                };
            } else if (!results.Age) {
                user = {
                    username: username,
                    userID: results._id, //Will come from database
                    age: null,
                    email: results.Email,
                    questions: [
                        ["What is your favorite color?", results.Questions[0]],
                        ["What is your favorite animal?", results.Questions[1]],
                        ["What is your favorite food?", results.Questions[2]]
                    ],
                    isAdmin: false,
                    lastVisit: new Date()
                };
            } else {
                var user = {
                    username: username,
                    userID: results._id, //Will come from database
                    age: results.Age,
                    email: results.Email,
                    questions: [
                        ["What is your favorite color?", results.Questions[0]],
                        ["What is your favorite animal?", results.Questions[1]],
                        ["What is your favorite food?", results.Questions[2]]
                    ],
                    isAdmin: false,
                    lastVisit: new Date()
                };
            }
            console.log(user);

            req.session.user = user;
            res.cookie("LastLogin", user.lastVisit);

            res.redirect("/");
            // res.render("Profile");
        } else {
            let model = {
                errorMsg: "Invalid username or password",
                username: username,
                password: password
            }
            console.log("invalid login");
            res.render("login", model);
        }
    } else {
        let model = {
            errorMsg: "Invalid username or password",
            username: username,
            password: password
        }
        console.log("invalid login");
        res.render("login", model);
    }

    //Check database to see if we have matching username
    //passwords match?

    // If login is valid, send to homepage
    // If so, set the session to have the user_id?

    // If not, send back to login page
});

router.get("/account", (req, res) => {
    let model = {
        loggedInUser: req.session.user
    }
    res.render("account", model);
});

router.post("/account", async (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    let confirmPassword = req.body.confirmPassword;
    let email = req.body.email;
    let age = req.body.age;
    let questions = [req.body.question1, req.body.question2, req.body.question3];
    let userID = req.session.user.userID;

    let model = {
        loggedInUser: req.session.user
    }

    if (password == confirmPassword && password.length > 0) {
        let hashedPass = await bcrypt.hash(password, 10);
        
        let result = dal.updateUser(userID, hashedPass, email, age, questions);
        res.redirect("/u/account");
    } else {
        res.render("account", model);
    }
});

module.exports = router;