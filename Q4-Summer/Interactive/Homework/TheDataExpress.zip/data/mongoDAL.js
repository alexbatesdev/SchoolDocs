// DAL = Data Access Layer
// CRUD = Create, Read, Update, Delete

// Connect to database
// npm i --save mongodb
const { MongoClient, ObjectId } = require('mongodb');

const uri = "mongodb://localhost:27017";
const dbName = "TestDB";
const collectionName = "Users";

const createUser = async (username, password, email, age, questions) => {
    const client = await MongoClient.connect(uri);

    try {
        const db = client.db(dbName);

        const collection = db.collection("Users");

        var newUser = {
            Username: username,
            Password: password,
            Email: email,
            Age: age,
            Questions: questions
        };

        var results = await collection.insertOne(newUser);
        console.log(results);

        return results;

    } catch (err) {
        console.log(err);

    } finally {
        client.close();
    }
}

const getUser = async (username) => {
    const client = await MongoClient.connect(uri);

    try {
        const db = client.db(dbName);

        const collection = db.collection("Users");

        var results = await collection.findOne({ Username: username });
        //console.log("RESULTS: ");
        //console.log(results);

        return results;

    } catch (err) {
        console.log(err);
    } finally {
        client.close();
    }
}

const updateUser = async (id, password, email, age, questions) => {
    const client = await MongoClient.connect(uri);

    try {
        const db = client.db(dbName);

        const collection = db.collection("Users");

        var results = await collection.updateOne({ _id: new ObjectId(id)}, { $set: { Password: password, Email: email, Age: age, Questions: questions } });

        return results;

    } catch (err) {
        console.log(err);
    } finally {
        client.close();
    }
}

exports.createUser = createUser;
exports.getUser = getUser;
exports.updateUser = updateUser;