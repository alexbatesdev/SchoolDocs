const add = (x,y) => {
    return x + y;
}

const sub = (x, y) => {
    return x - y;
}

exports.calc = {
    add: add,
    sub: sub
}

// exports.add = add;
// exports.sub = sub;