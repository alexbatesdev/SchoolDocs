package edu.neumont;

public interface Vehicle {
    int i = 5;

    public void Accelerate();
    public void Brake();

    static void run() {

    }
}
