package edu.neumont;

public interface IAcceleratable {
    void accelerate();
}
