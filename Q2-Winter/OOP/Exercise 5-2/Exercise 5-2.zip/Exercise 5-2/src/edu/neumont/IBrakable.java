package edu.neumont;

public interface IBrakable {
    void brake();
}
