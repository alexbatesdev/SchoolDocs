package edu.neumont;

public class Main {

    public static void main(String[] args) {
        Controller controller = new Controller();
        controller.run();
        //Interface with encrypt and decrypt functions
        //Make 4 classes that do different encrpytions and decryptions
        //3 are specific, 1 is anything I want


        //MENU
        // addIStringEncrypter
        // display encrypters
        // clear encrypters
        // enter string
        // encrypt string
        // decrypt string
        // view string
        // exit
    }
}
