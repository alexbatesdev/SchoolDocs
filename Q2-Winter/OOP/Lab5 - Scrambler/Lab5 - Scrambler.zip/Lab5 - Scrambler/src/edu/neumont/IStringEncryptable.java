package edu.neumont;

public interface IStringEncryptable {
    String encrypt(String s);
    String decrypt(String s);
}
