﻿using ConsoleLibrary;
namespace Foundation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World! Welcome to this example project");
            //DataTypes.Execute();
            //Strings.Execute();
            //Converting.Execute();
            //ValueReference.Execute();
            //Parameters.Execute();
            //Arrays.Execute();
            //Debug.Execute();
            IO.Print("THUD");
            IO.Ticket("VALUE");
        }
    }
}