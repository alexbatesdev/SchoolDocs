﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Collections;
using System.Linq;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for DB.xaml
    /// </summary>
    public partial class DB : Window
    {
        public DB()
        {
            InitializeComponent();
        }

        private void ExecuteButton_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt;
            Hashtable ht = new Hashtable();
            string sql;
            long returnedID;

            ht.Clear();
            sql = "SELECT * FROM Names";
            //sql = "SELECT Username, Password FROM Users WHERE Username=@Username and Password=@Password";
            //sql = "SELECT * FROM Names WHERE ID=@ID";
            ht.Add("@ID", 3);
            dt = ExDB.GetDataTable("ApplicationDevelopement", ht, sql);
            MyDataGrid.ItemsSource = dt.DefaultView;

            DataRow dr;
            dr = dt.Rows[0];
            int x = (int)dr["ID"];
            ResultLabel.Content = x.ToString();
            ResultLabel.Content = dr["FirstName"];

            //if (dt.Rows.Count > 0)
            //{
            //    ResultLabel.Content = "Found";
            //}
            //else
            //{
            //    ResultLabel.Content = "Not Found";
            //}

            ht.Clear();
            sql = "INSERT INTO Names (FirstName, LastName) VALUES (@FirstName, @LastName)";
            ht.Add("@FirstName", "John");
            ht.Add("@LastName", "Smith");
            returnedID = ExDB.ExecuteIt("ApplicationDevelopement", sql, ht);
            ResultLabel.Content = returnedID.ToString();
        }
    }
}
