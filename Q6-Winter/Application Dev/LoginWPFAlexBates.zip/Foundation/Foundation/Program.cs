﻿using ConsoleLibrary;
namespace Foundation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World! Welcome to this example project");
            //DataTypes.Execute();
            //Strings.Execute();
            //Converting.Execute();
            //ValueReference.Execute();
            //Parameters.Execute();
            //Arrays.Execute();
            //Debug.Execute();
            //IO.Print("THUD");
            //IO.Ticket("VALUE");
            //IO.GetConsoleInt("Enter a number", 1, 10);
            //IO.GetConsoleFloat("Enter a number", 1, 10);
            //IO.GetConsoleBool("Enter a value");
            //IO.GetConsoleString("Enter a string");
            //List<string> list = new List<string> { "One", "Two", "Three" };
            //IO.GetConsoleMenu(list, "Pick one");
            //Inheritance.Execute();
            //CodeSnippets.Execute();
            //Generics.Execute();
            ExtensionMethods.Execute();
        }
    }
}