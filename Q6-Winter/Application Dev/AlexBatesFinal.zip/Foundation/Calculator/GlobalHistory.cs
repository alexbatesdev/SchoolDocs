﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class GlobalHistory
    {
        public static List<string> EquationHistory = new List<string>();
        public static List<string> AnswerHistory = new List<string>();

    }
}
