# Test Procedures/Things to test for

 - Valid input when asked for int
	- in range
	- is an int
 - Valid answer generated (matches difficulty)
 - attempt gets checked once full attempt is entered
 - correctly validates a correct guess
 - menu inputs actually correspond to desired output
 - correctly check for win/lost conditions
 - attempts decriment correctly
 - Make sure the user can't input colors that aren't in the game