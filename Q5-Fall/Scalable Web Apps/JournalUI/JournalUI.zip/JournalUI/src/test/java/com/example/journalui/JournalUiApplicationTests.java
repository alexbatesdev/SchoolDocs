package com.example.journalui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JournalUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
