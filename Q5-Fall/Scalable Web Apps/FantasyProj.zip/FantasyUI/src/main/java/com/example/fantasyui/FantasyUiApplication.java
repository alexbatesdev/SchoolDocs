package com.example.fantasyui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FantasyUiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FantasyUiApplication.class, args);
    }

    //TODO: make a ui

}
