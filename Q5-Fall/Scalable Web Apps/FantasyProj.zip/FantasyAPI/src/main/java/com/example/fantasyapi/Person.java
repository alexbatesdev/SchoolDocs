package com.example.fantasyapi;

public class Person {
    public int id;
    public String name;
    public boolean isDeceased;
    public String description;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getIsDeceased() {
        return isDeceased;
    }

    public void setIsDeceased(boolean isDeceased) {
        this.isDeceased = isDeceased;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", data='" + description + '\'' +
                '}';
    }

    //Key Value Pair stuff, probably won't actually use due to having a specific data model
//    private Map<String, String> properties;
//
//    @JsonAnyGetter
//    public Map<String, String> getProperties() {
//        return properties;
//    }
}
