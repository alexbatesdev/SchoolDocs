package com.example.fantasyapi;

import java.util.ArrayList;

public class JSONModel {
    public ArrayList<Person> people = new ArrayList<Person>();
    public ArrayList<Devil> devils = new ArrayList<Devil>();
    public ArrayList<Location> locations = new ArrayList<Location>();

}
