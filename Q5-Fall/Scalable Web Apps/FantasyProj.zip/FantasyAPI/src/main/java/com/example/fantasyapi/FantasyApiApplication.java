package com.example.fantasyapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class FantasyApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FantasyApiApplication.class, args);
    }


    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins("*").allowedMethods("*"); //allow from anywhere
                //registry.addMapping("/**").allowedOrigins("http://localhost:8082/").allowedMethods("*"); //allow from only ui
            }
        };
    }

    //TODO:
    //Make data model classes check
    //Make methods to create, update, delete, and get data from json file (BLL) check
    //Make UI in other project

}
