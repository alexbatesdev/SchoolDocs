package com.example.fantasyapi.Models;

public class Person {
    private int id;
    private String name;
    private boolean isDeceased;
    private String description;

    public Person(int id, String name, boolean isDeceased, String description) {
        this.id = id;
        this.name = name;
        this.isDeceased = isDeceased;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getIsDeceased() {
        return isDeceased;
    }

    public void setIsDeceased(boolean isDeceased) {
        this.isDeceased = isDeceased;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", data='" + description + '\'' +
                '}';
    }

}
