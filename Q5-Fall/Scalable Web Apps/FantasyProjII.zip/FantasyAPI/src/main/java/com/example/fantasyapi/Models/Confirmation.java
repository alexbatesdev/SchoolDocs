package com.example.fantasyapi.Models;

public class Confirmation {
    private String message;
    private String method;
    private Object object;

    public Confirmation(String message, String method, Object item) {
        this.message = message;
        this.method = method;
        this.object = item;
    }

    @Override
    public String toString() {
        return "Confirmation{" +
                "message='" + message + '\'' +
                ", method='" + method + '\'' +
                ", object=" + object +
                '}';
    }
}
