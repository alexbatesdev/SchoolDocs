from timeit import default_timer as timer

# Bubble sort
def bubbleSort(array: list):
    array = array.copy()
    unsorted = True
    bigLoops = 0
    while unsorted:
        swapOperation = False
        for index in range(len(array) - 1 - bigLoops):
            if array[index + 1] < array[index]:
                print(array)
                # input(">")
                swapOperation = True
                greaterNum = array[index]
                lesserNum = array[index + 1]
                array[index] = lesserNum
                array[index + 1] = greaterNum
        if swapOperation == False:
            print(array)
            unsorted = False
        bigLoops += 1
    return array

# Selection sort
def selectionSort(array: list):
    def findIndexOfSmallestNum(array: list):
        smallest = array[0]
        for number in array:
            if number < smallest:
                smallest = number
        
        return array.index(smallest)

    array = array.copy()
    if len(array) == 0:
        return []
    unsorted = True
    iterations = 0
    while unsorted:
        print(array)
        # input(">")
        smallestNumIndex = findIndexOfSmallestNum(array[iterations:])
        smallestNum = array[smallestNumIndex + iterations]
        swappedNum = array[iterations]
        array[iterations] = smallestNum
        array[smallestNumIndex + iterations] = swappedNum
        iterations += 1
        if (iterations == len(array)):
            print(array)
            unsorted = False
    return array

# Insertion sort
def insertionSort(array: list):
    # Select item (starting at index 1, not 0)
    # Compare with item before selected number
    # If item before selected number is greater than selected number
        # move item left, check again for lesser number to the left
            # if Item before selected number is less than current number then place current number
    array = array.copy()
    for index in range(len(array)):
        if index == 0: continue
        grabbedNum = array[index]
        unnamedBool = True
        reach = 1
        reachOffset = 0
        while unnamedBool:
            if index - reach < 0:
                unnamedBool = False
                break
            if array[index - reach] > grabbedNum:
                array[index - reachOffset] = array[index - reach]
                array[index - reach] = grabbedNum
                reachOffset += 1
                reach += 1
                print(array)
                # input(">")
            else:
                unnamedBool = False
    return array

# Merge Sort
def mergeSort(array: list):
    # split array into partitions of 1
    # Merge partitions 1 and 2, sort
    # Merge partitions 3 and 4, sort
    # repeat until all partitions merged once
    # merge partions [1,2] and [3,4], sort
    # repeat merging and sorting larger and larger partitions until complete
    def msort(arr1, arr2):
        output = []
        # Note here, I did need a hint to figure this out
        # I asked chatGPT to give me a hint without showing me any code or giving me the solution
        # The hint I needed was to use two indexes, one for each arra
        # I was trying to use a single index for both arrays and couldn't figure out how to compare the arrays properly like this
        arr1Index = 0
        arr2Index = 0
        while arr1Index < len(arr1) and arr2Index < len(arr2):
            if (arr1[arr1Index] < arr2[arr2Index]):
                output.append(arr1[arr1Index])
                arr1Index += 1
            else:
                output.append(arr2[arr2Index])
                arr2Index += 1
        if (arr1Index < len(arr1)):
            output.extend(arr1[arr1Index:])
        if (arr2Index < len(arr2)):
            output.extend(arr2[arr2Index:])
        return output

    if (len(array) <= 1):
        return array
    array = array.copy()
    otherArray = []
    for item in array:
        otherArray.append([item])
    print(otherArray)

    while len(otherArray) > 1:
        # Merge Partitions
        for item in otherArray[::2]:
            if (otherArray.index(item) + 1 < len(otherArray)):
                tempPartition = msort(item, otherArray[otherArray.index(item) + 1])
                otherArray.pop(otherArray.index(item) + 1)
                otherArray[otherArray.index(item)] = tempPartition
        print(otherArray)
    
    return otherArray[0]

# ------------------------------------------------------------

def timetheFunc(func, array):
    print("Timing function: " + func.__name__)
    start = timer()
    func(array)
    end = timer()
    print("Function took " + str((end - start) * 10000) + " ms to execute")


array = [4, 5, 50, 2, 10, 17, 20]
array2 = [2, 6, 4, 3, 1]


# timetheFunc(bubbleSort, array)
# timetheFunc(selectionSort, array)
# timetheFunc(insertionSort, array)

# insertionSort(array)
# mergeSort(array)