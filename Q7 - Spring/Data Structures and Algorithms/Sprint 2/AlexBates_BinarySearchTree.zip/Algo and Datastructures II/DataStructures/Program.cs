﻿namespace DataStructures
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //BinaryTree<int> tree = new BinaryTree<int>();
            //tree.Add(10);
            //tree.Add(5);
            //tree.Add(15);
            //tree.Add(4);
            ////Console.WriteLine(tree.Count);
            //tree.Add(6);
            //tree.Add(25);
            //tree.Add(16);
            //tree.Add(17);
            //tree.Add(18);
            //tree.Add(19);
            ////tree.Clear();
            ////Console.WriteLine(tree.Count);
            //int[] array = (int[])tree.ToArray();
            //tree.Remove(5);
            ////Console.WriteLine(tree.Count);
            //tree.Remove(25);
            ////Console.WriteLine(tree.Count);
            ////tree.Remove(16);
            //tree.Remove(17);
            ////Console.WriteLine(tree.Count);
            ////tree.Remove(18);


            ////Console.WriteLine(tree.PostOrder());
            //Console.WriteLine(tree.InOrder());

            ////Console.WriteLine(tree.PreOrder());

            //for (int i = 0; i < array.Length; i++)
            //{
            //    Console.Write(array[i] + " ");
            //    Console.WriteLine(tree.Contains(array[i]));
            //}

            //Console.WriteLine(tree.Height());

            //BinaryTree<int> tree = new BinaryTree<int>();
            //tree.Add(10);
            //tree.Add(10);
            //tree.Add(15);
            //tree.Remove(10);

            //string treeString = tree.InOrder();
            //Console.WriteLine(treeString);

            //BinaryTree<int> tree = new BinaryTree<int>();
            //tree.Add(5);
            //tree.Add(3);
            //tree.Add(1);
            //tree.Add(8);
            //tree.Add(0);
            //tree.Add(0);
            //tree.Add(8);
            //Console.WriteLine("Input Order (What Pre Order should Equal)");
            //Console.WriteLine("5, 3, 1, 8, 0, 0, 8");

            //Console.WriteLine("In Order");
            //Console.WriteLine(tree.InOrder());
            //Console.WriteLine("Pre Order");
            //Console.WriteLine(tree.PreOrder());
            //Console.WriteLine("Post Order");
            //Console.WriteLine(tree.PostOrder());
            //int[] intArray = (int[])tree.ToArray(); //<--------------------------------------------- ASK ABOUT ME <--------------------------------------------------
            //int[] expectedIntArray = new int[] { 0, 0, 1, 3, 5, 8, 8 };



        }
    }
}