﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructures
{
    public class BinaryTree<T> where T : IComparable<T>
    {
        public BinaryTreeNode<T> Root;
        public int count { get; private set; }
    }

    public class BinaryTreeNode<T> where T : IComparable<T>
    {
        public T Value;
        public BinaryTreeNode<T> parent;
        public BinaryTreeNode<T> left;
        public BinaryTreeNode<T> right;
    }
}
