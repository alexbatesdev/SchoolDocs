﻿using DataStructures;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BinaryTree
{

    [TestClass]
    public class BinaryTreeTests
    {
        [TestMethod]
        public void BST_AddOne()
        {
            //Test if you can add one 
            BinaryTree<int> tree = new BinaryTree<int>();

            //tree.Add(1);

            //Assert.AreEqual(1, tree.Count);
        }
    }
}
