﻿namespace DataStructures
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //SingleLinkedList<int> list = new SingleLinkedList<int>(new int[] { 1, 2, 3, 4, 13 });

            //list.Insert(5, 0);

            //Console.WriteLine(list.ToString());

            //Console.WriteLine(list.Search(13));

            //SingleLinkedList<int> sll = new SingleLinkedList<int>(new int[] { 5, 3, 1, 8, 0, 8 });
            //sll.Insert(0, sll.Count - 1);

            //Console.WriteLine(sll.ToString());

            //DoubleLinkedList<int> list = new DoubleLinkedList<int>(new int[] { 6, 7, 9, 6  });
            //list.Add(1);
            //list.Add(2);
            //list.Add(3);
            //list.Add(4);

            //list.Insert(0, 5);
            //Console.WriteLine(list.ToString());
            //Console.WriteLine(list.Count);
            //list.RemoveFirst();
            //list.RemoveLast();
            //list.RemoveAt(4);

            //Console.WriteLine(list.ToString());
            //Console.WriteLine(list.Count);


        }
    }
}