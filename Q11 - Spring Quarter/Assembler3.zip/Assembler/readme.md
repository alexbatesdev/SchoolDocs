# Python Assembler for Programming Languages Class

Run with
```
python assemler.py --debug
```

with or without debug flag