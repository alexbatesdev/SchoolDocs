// This code was written with the help of an AI assistant.
const AWS = require('aws-sdk');
const eks = new AWS.EKS();

exports.handler = async (event) => {
    const { clusterName } = event;

    try {
        await eks.deleteCluster({ name: clusterName }).promise();
        return {
            statusCode: 200,
            body: JSON.stringify(`EKS cluster ${clusterName} deletion initiated`)
        };
    } catch (error) {
        console.error(`Error deleting EKS cluster: ${error}`);
        return {
            statusCode: 500,
            body: JSON.stringify('Error deleting EKS cluster')
        };
    }
};