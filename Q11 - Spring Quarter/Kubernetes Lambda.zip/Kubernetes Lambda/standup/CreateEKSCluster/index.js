// 1
// This code was written with the help of an AI assistant.
const AWS = require('aws-sdk');
const eks = new AWS.EKS();

exports.handler = async (event) => {
    const clusterName = "Gezora-Godzooky-Cluster";
    // Replace with actual values
    const roleArn = "arn:aws:iam::123456789012:role/eks-role";
    const subnets = ["subnet-12345678", "subnet-23456789"];
    const securityGroup = "sg-0123456789abcdef0";
    // Get the latest EKS version via a method in the main index.js file
    const version = "1.21";

    try {
        const response = await eks.createCluster({
            name: clusterName,
            version: version,
            roleArn: roleArn,
            resourcesVpcConfig: {
                subnetIds: subnets,
                securityGroupIds: [securityGroup]
            }
        }).promise();

        return {
            statusCode: 200,
            body: JSON.stringify(response)
        };
    } catch (error) {
        console.error(`Error creating EKS cluster: ${error}`);
        return {
            statusCode: 500,
            body: JSON.stringify('Error creating EKS cluster')
        };
    }
};
