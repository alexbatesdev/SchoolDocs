// This code was written with the help of an AI assistant.
const AWS = require('aws-sdk');
const eks = new AWS.EKS();

exports.handler = async (event) => {
    const { clusterName } = event;

    try {
        const response = await eks.describeCluster({ name: clusterName }).promise();
        const clusterStatus = response.cluster.status;
        return {
            statusCode: 200,
            body: JSON.stringify({ clusterStatus })
        };
    } catch (error) {
        console.error(`Error checking EKS cluster status: ${error}`);
        return {
            statusCode: 500,
            body: JSON.stringify('Error checking EKS cluster status')
        };
    }
};
