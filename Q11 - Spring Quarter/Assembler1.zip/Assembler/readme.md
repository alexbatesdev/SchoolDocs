Load File
Iterate Through Lines
Split line by ' '
First word is the command
Load method from command
Feed method the rest of the line as args
Append the binary result to the output
iterate through the output and swap every 8 bits
Convert to hex, maybe?