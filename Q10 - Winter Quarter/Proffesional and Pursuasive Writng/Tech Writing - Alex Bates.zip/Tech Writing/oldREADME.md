Use EventBridge to schedule Lambdas

Frontend is gonna be raw html, css, and javascript. No frameworks.

run API locally

```bash
sam local start-api
```

Deploy API

```bash
sam build && sam deploy --no-confirm-changeset
```