The .env files aren't being used for secrets, so they should probably be fint to be pushed to github

The .env files are so I don't have to keep track of which things need to be the same value between files. (Docker image name being the one on my mind right now)