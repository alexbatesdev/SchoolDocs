`sam validate`
`sam build`
`sam deploy`
`sam list endpoints --stack-name TodoPeopleSAM --output json`
`sam invoke local FunctionName`
`sam delete`