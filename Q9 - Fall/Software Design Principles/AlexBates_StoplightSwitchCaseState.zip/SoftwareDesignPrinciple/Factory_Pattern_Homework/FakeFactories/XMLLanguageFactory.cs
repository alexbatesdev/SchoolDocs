﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Pattern_Homework
{
    internal class XMLLanguageFactory : LanguageFactoryAbstract
    {
        public override string Create(AbstractComponent component)
        {
            switch (component)
            {
                case BoxComponent boxComponent:
                    StringBuilder xmlBox = new StringBuilder();
                    xmlBox.Append("<component>");
                    xmlBox.Append("<style>");
                    xmlBox.Append($"position:absolute;background-color:{boxComponent._backgroundColor};");
                    xmlBox.Append($"width:{boxComponent._width}px;height:{boxComponent._height}px;");
                    xmlBox.Append($"left:{boxComponent._left}px;top:{boxComponent._top}px;");
                    xmlBox.Append("</style>");
                    xmlBox.Append("<text>");
                    xmlBox.Append(boxComponent._text);
                    xmlBox.Append("</text>");
                    xmlBox.Append("</component>");
                    return xmlBox.ToString();
                case CheckComponent checkComponent:
                    StringBuilder xmlCheckbox = new StringBuilder();
                    xmlCheckbox.Append("<component type='checkbox'>");
                    xmlCheckbox.Append("<style>");
                    xmlCheckbox.Append($"position:absolute;left:{checkComponent._left}px;top:{checkComponent._top}px;");
                    xmlCheckbox.Append("</style>");
                    xmlCheckbox.Append("<text>");
                    xmlCheckbox.Append(checkComponent._text);
                    xmlCheckbox.Append("</text>");
                    xmlCheckbox.Append("</component>");
                    return xmlCheckbox.ToString();
                case ButtonComponent buttonComponent:
                    StringBuilder xmlButton = new StringBuilder();
                    xmlButton.Append("<component type='button'>");
                    xmlButton.Append("<style>");
                    xmlButton.Append($"position:absolute;left:{buttonComponent._left}px;top:{buttonComponent._top}px;");
                    xmlButton.Append("</style>");
                    xmlButton.Append("<text>");
                    xmlButton.Append(buttonComponent._text);
                    xmlButton.Append("</text>");
                    xmlButton.Append("</component>");
                    return xmlButton.ToString();
                default:
                    StringBuilder xmlOutput = new StringBuilder();
                    xmlOutput.Append("<component>");
                    xmlOutput.Append("<style>");
                    xmlOutput.Append($"position:absolute;background-color:{component._backgroundColor};");
                    xmlOutput.Append($"width:{component._width}px;height:{component._height}px;");
                    xmlOutput.Append($"left:{component._left}px;top:{component._top}px;");
                    xmlOutput.Append("</style>");
                    xmlOutput.Append("<text>");
                    xmlOutput.Append(component._text);
                    xmlOutput.Append("</text>");
                    xmlOutput.Append("</component>");
                    return xmlOutput.ToString();
            }
        }
    }
}
