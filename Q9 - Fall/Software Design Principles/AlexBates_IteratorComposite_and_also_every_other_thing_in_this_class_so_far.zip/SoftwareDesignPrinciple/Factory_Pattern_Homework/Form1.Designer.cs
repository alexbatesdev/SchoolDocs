﻿namespace Factory_Pattern_Homework
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdd_Item = new System.Windows.Forms.Button();
            this.buttonExport = new System.Windows.Forms.Button();
            this.Undo = new System.Windows.Forms.Button();
            this.outputPreview = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAdd_Item
            // 
            this.buttonAdd_Item.Location = new System.Drawing.Point(12, 12);
            this.buttonAdd_Item.Name = "buttonAdd_Item";
            this.buttonAdd_Item.Size = new System.Drawing.Size(75, 23);
            this.buttonAdd_Item.TabIndex = 0;
            this.buttonAdd_Item.Text = "Text";
            this.buttonAdd_Item.UseVisualStyleBackColor = true;
            this.buttonAdd_Item.Click += new System.EventHandler(this.buttonAdd_Item_Click);
            // 
            // buttonExport
            // 
            this.buttonExport.Location = new System.Drawing.Point(713, 12);
            this.buttonExport.Name = "buttonExport";
            this.buttonExport.Size = new System.Drawing.Size(75, 23);
            this.buttonExport.TabIndex = 3;
            this.buttonExport.Text = "Export";
            this.buttonExport.UseVisualStyleBackColor = true;
            // 
            // Undo
            // 
            this.Undo.Location = new System.Drawing.Point(632, 12);
            this.Undo.Name = "Undo";
            this.Undo.Size = new System.Drawing.Size(75, 23);
            this.Undo.TabIndex = 4;
            this.Undo.Text = "Undo";
            this.Undo.UseVisualStyleBackColor = true;
            // 
            // outputPreview
            // 
            this.outputPreview.Location = new System.Drawing.Point(12, 41);
            this.outputPreview.Name = "outputPreview";
            this.outputPreview.Size = new System.Drawing.Size(776, 397);
            this.outputPreview.TabIndex = 5;
            this.outputPreview.TabStop = false;
            this.outputPreview.Text = "Preview";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(93, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Check";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(174, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Button";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.outputPreview);
            this.Controls.Add(this.Undo);
            this.Controls.Add(this.buttonExport);
            this.Controls.Add(this.buttonAdd_Item);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAdd_Item;
        private System.Windows.Forms.Button buttonExport;
        private System.Windows.Forms.Button Undo;
        private System.Windows.Forms.GroupBox outputPreview;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

