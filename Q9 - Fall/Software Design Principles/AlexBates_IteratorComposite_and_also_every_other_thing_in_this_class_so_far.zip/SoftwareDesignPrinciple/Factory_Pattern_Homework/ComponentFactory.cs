﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Factory_Pattern_Homework
{
    public static class ComponentFactory
    {
        public static Object CreateComponent(BasicComponent basicComponent, Language type)
        {
            string componentType = basicComponent._ComponentType;
            Object output = null;
            switch (componentType)
            {
                case "box": //Create a factory that replaces this switch case 💭
                    switch (type)
                    {
                        case Language.html:
                            StringBuilder sb = new StringBuilder();
                            sb.Append($"<div style='position:absolute;background-color:{basicComponent._backgroundColor};");
                            sb.Append($"width:{basicComponent._width};height:{basicComponent._height};");
                            sb.Append($"left:{basicComponent._left}px;top:{basicComponent._top}px;>\n");
                            sb.Append(basicComponent._text + "\n");
                            sb.Append("</div>");
                            output = sb.ToString();
                            break;
                        case Language.xml:
                            StringBuilder xmlOutput = new StringBuilder();
                            xmlOutput.Append("<component>");
                            xmlOutput.Append("<style>");
                            xmlOutput.Append($"position:absolute;background-color:{basicComponent._backgroundColor};");
                            xmlOutput.Append($"width:{basicComponent._width}px;height:{basicComponent._height}px;");
                            xmlOutput.Append($"left:{basicComponent._left}px;top:{basicComponent._top}px;");
                            xmlOutput.Append("</style>");
                            xmlOutput.Append("<text>");
                            xmlOutput.Append(basicComponent._text);
                            xmlOutput.Append("</text>");
                            xmlOutput.Append("</component>");
                            output = xmlOutput.ToString();
                            break;
                        case Language.forms: 
                            Panel panel = new Panel();
                            Label label = new Label();
                            label.Text = basicComponent._text;
                            panel.Controls.Add(label);
                            panel.Width = basicComponent._width;
                            panel.Height = basicComponent._height;
                            panel.BackColor = GetColor(basicComponent._backgroundColor);
                            panel.Left = basicComponent._left;
                            panel.Top = basicComponent._top;
                            output = panel;
                            break;
                    }
                    break;
                // Assistant generated code for checkbox starts here //I had GPT generate this because I already did the work for the first one
                case "checkbox":
                    switch (type)
                    {
                        case Language.html:
                            StringBuilder sbCheckbox = new StringBuilder();
                            sbCheckbox.Append($"<input type='checkbox' style='position:absolute;left:{basicComponent._left}px;top:{basicComponent._top}px;' ");
                            sbCheckbox.Append($"value='{basicComponent._text}' />");
                            output = sbCheckbox.ToString();
                            break;

                        case Language.xml:
                            StringBuilder xmlCheckbox = new StringBuilder();
                            xmlCheckbox.Append("<component type='checkbox'>");
                            xmlCheckbox.Append("<style>");
                            xmlCheckbox.Append($"position:absolute;left:{basicComponent._left}px;top:{basicComponent._top}px;");
                            xmlCheckbox.Append("</style>");
                            xmlCheckbox.Append("<text>");
                            xmlCheckbox.Append(basicComponent._text);
                            xmlCheckbox.Append("</text>");
                            xmlCheckbox.Append("</component>");
                            output = xmlCheckbox.ToString();
                            break;

                        case Language.forms:
                            CheckBox checkBox = new CheckBox();
                            checkBox.Text = basicComponent._text;
                            checkBox.Left = basicComponent._left;
                            checkBox.Top = basicComponent._top;
                            // My addition
                            checkBox.BackColor = GetColor(basicComponent._backgroundColor);
                            output = checkBox;
                            break;
                    }
                    break;
                // Assistant generated code for checkbox ends here

                // Assistant generated code for button starts here
                case "button":
                    switch (type)
                    {
                        case Language.html:
                            StringBuilder sbButton = new StringBuilder();
                            sbButton.Append($"<button style='position:absolute;left:{basicComponent._left}px;top:{basicComponent._top}px;'>");
                            sbButton.Append(basicComponent._text);
                            sbButton.Append("</button>");
                            output = sbButton.ToString();
                            break;

                        case Language.xml:
                            StringBuilder xmlButton = new StringBuilder();
                            xmlButton.Append("<component type='button'>");
                            xmlButton.Append("<style>");
                            xmlButton.Append($"position:absolute;left:{basicComponent._left}px;top:{basicComponent._top}px;");
                            xmlButton.Append("</style>");
                            xmlButton.Append("<text>");
                            xmlButton.Append(basicComponent._text);
                            xmlButton.Append("</text>");
                            xmlButton.Append("</component>");
                            output = xmlButton.ToString();
                            break;

                        case Language.forms:
                            Button button = new Button();
                            button.Text = basicComponent._text;
                            button.Left = basicComponent._left;
                            button.Top = basicComponent._top;
                            // My addition
                            button.BackColor = GetColor(basicComponent._backgroundColor);
                            output = button;
                            break;
                    }
                    break;
                // Assistant generated code for button ends here
                default:
                    break;
            }
            return output;
        }

        private static Color GetColor(string colorString)
        {
            Color color = Color.Transparent;
            switch (colorString)
            {
                case "Red":
                    color = Color.Red;
                    break;
                case "Orange":
                    color = Color.Orange;
                    break;
                case "Yellow":
                    color = Color.Yellow;
                    break;
                case "Green":
                    color = Color.Green;
                    break;
                case "Blue":
                    color = Color.Blue;
                    break;
                case "Indigo":
                    color = Color.Indigo;
                    break;
                case "Violet":
                    color = Color.Purple;
                    break;
                case "White":
                    color = Color.White;
                    break;
                case "Gray":
                    color = Color.Gray;
                    break;
                case "Black":
                    color = Color.Black;
                    break;
                case "Transparent": //Technically not needed
                    color = Color.Transparent; 
                    break;
                default:
                    break;
            }
            return color;
        }
    }
    public enum Language { html, xml, forms }
}
