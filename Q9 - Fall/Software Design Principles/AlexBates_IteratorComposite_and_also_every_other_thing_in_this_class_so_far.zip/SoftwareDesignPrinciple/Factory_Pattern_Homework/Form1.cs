﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Windows;

namespace Factory_Pattern_Homework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public List<BasicComponent> componentsList = new List<BasicComponent>();

        private void buttonAdd_Item_Click(object sender, EventArgs e)
        {
            Add_Options popup = new Add_Options(componentsList.Count, "box");
            popup.ShowDialog();

            if (popup.DialogResult == DialogResult.Cancel) return;

            string component = popup.component;
            string backgroundColor = popup.backgroundColor;
            string text = popup.text;
            int left = popup.left;
            int top = popup.top;
            int width = popup.width;
            int height = popup.height;

            BasicComponent newComponent = new BasicComponent(component, backgroundColor, text, left, top, width, height);
            componentsList.Add(newComponent);

            RenderPreview(componentsList);
            
        }

        private void RenderPreview(List<BasicComponent> components)
        {
            outputPreview.Controls.Clear();
            foreach (BasicComponent component in components)
            {
                outputPreview.Controls.Add((Control)ComponentFactory.CreateComponent(component, Language.forms));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Add_Options popup = new Add_Options(componentsList.Count, "checkbox");
            popup.ShowDialog();

            if (popup.DialogResult == DialogResult.Cancel) return;

            string component = popup.component;
            string backgroundColor = popup.backgroundColor;
            string text = popup.text;
            int left = popup.left;
            int top = popup.top;
            int width = popup.width;
            int height = popup.height;

            BasicComponent newComponent = new BasicComponent(component, backgroundColor, text, left, top, width, height);
            componentsList.Add(newComponent);

            RenderPreview(componentsList);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Add_Options popup = new Add_Options(componentsList.Count, "button");
            popup.ShowDialog();

            if (popup.DialogResult == DialogResult.Cancel) return;

            string component = popup.component;
            string backgroundColor = popup.backgroundColor;
            string text = popup.text;
            int left = popup.left;
            int top = popup.top;
            int width = popup.width;
            int height = popup.height;

            BasicComponent newComponent = new BasicComponent(component, backgroundColor, text, left, top, width, height);
            componentsList.Add(newComponent);

            RenderPreview(componentsList);
        }
    }
}
