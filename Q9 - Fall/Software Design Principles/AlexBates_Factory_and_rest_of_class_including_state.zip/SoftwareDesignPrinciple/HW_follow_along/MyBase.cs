﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_follow_along
{
    public class MyBase
    {
        public virtual string WriteFile(string content)
        {
            return null;
        }
    }
}
